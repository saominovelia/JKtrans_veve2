<?php

$dbHost = 'localhost';
$dbName = 'nota';
$dbUsername = 'root';
$dbPassword = '';

$mysqli = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

?>
